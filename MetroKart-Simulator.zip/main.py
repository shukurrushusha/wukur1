balance = 0
debt = 0
daily_limit = 100
daily_added = 0

rides = 0
total_paid = 0
total_discount = 0

history = []
mode = "normal"

correct_pin = "1234"
attempts = 0

while attempts < 3:
    pin = input("PIN daxil edin: ")
    if pin == correct_pin:
        print("Giriş uğurludur")
        break
    else:
        attempts += 1
        print("Yanlış PIN")

if attempts == 3:
    print("Kart bloklandı")
    exit()

while True:
    print("\n1) Balansı göstər")
    print("2) Balans artır")
    print("3) Gediş et")
    print("4) Son əməliyyatlar")
    print("5) Statistikalar")
    print("6) Parametrlər")
    print("0) Çıxış")

    choice = input("Seçim edin: ")

    if choice == "1":
        print("Balans:", balance, "Borç:", debt)

    elif choice == "2":
        amount = float(input("Məbləğ daxil et: "))
        if amount <= 0:
            print("Yanlış məbləğ")
            continue
        if daily_added + amount > daily_limit:
            print("Günlük limit aşılır")
            continue

        daily_added += amount

        if debt > 0:
            if amount >= debt:
                amount -= debt
                debt = 0
            else:
                debt -= amount
                amount = 0

        balance += amount
        history.append(("Artırma", amount, 0, balance))

    elif choice == "3":
        if mode == "student":
            price = 0.20
        elif mode == "pension":
            price = 0.15
        else:
            rides += 1
            if rides == 1:
                price = 0.40
            elif 2 <= rides <= 4:
                price = 0.36
                total_discount += 0.04
            else:
                price = 0.30
                total_discount += 0.10

        if balance >= price:
            balance -= price
            total_paid += price
            history.append(("Gediş", price, 0, balance))
            print("Keçid uğurludur")

        elif 0.30 <= balance < 0.40:
            print("Təcili keçid istifadə olundu")
            debt += 0.10
            balance = 0
        else:
            print("Balans kifayət deyil")

    elif choice == "4":
        n = int(input("Neçə əməliyyat göstərilsin: "))
        for item in history[-n:]:
            print(item)

    elif choice == "5":
        print("Gediş sayı:", rides)
        print("Ümumi ödəniş:", total_paid)
        print("Endirim cəmi:", total_discount)
        print("Günlük artırılan:", daily_added)

    elif choice == "6":
        print("1) Limit dəyiş")
        print("2) Rejim dəyiş")
        sub = input("Seçim: ")

        if sub == "1":
            daily_limit = float(input("Yeni limit: "))

        elif sub == "2":
            print("1) Normal")
            print("2) Tələbə")
            print("3) Pensiyaçı")

            m = input("Seç: ")

            if m == "1":
                mode = "normal"
            elif m == "2":
                mode = "student"
            elif m == "3":
                mode = "pension"

    elif choice == "0":
        print("Proqram bitdi")
        break
