# 🚇 MetroKart Simulyatoru

Bu proqram metro kart sistemini simulyasiya edir.

## 🔐 Xüsusiyyətlər
- PIN ilə giriş (3 cəhd)
- Balans artırma
- Gediş sistemi (endirimli)
- Son əməliyyatlar
- Statistikalar
- Parametrlər

## ▶️ Necə işlətmək olar
```bash
python main.py
```

## 📸 Screenshot
Screenshots qovluğuna əlavə edin.

## 👨‍💻 Müəllif
Şükür Quliyev
